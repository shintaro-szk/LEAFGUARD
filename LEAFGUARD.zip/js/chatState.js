const ChatState = {
    currentStep: 0,
    
    data: {
        plantType: '',
        symptoms: '',
        leafColorChanges: '',
        discoloration: '',
        wilting: '',
        environment: '',
        hasPhoto: false,
        photoData: null
    },
    
    isProcessing: false,
    conversationEnded: false,
    diagnosisResults: [],
    
    reset: function() {
        this.currentStep = 0;
        this.data = {
            plantType: '',
            symptoms: '',
            leafColorChanges: '',
            discoloration: '',
            wilting: '',
            environment: '',
            hasPhoto: false,
            photoData: null
        };
        this.isProcessing = false;
        this.conversationEnded = false;
        this.diagnosisResults = [];
    },
    
    setData: function(field, value) {
        if (this.data.hasOwnProperty(field)) {
            this.data[field] = value;
        }
    },
    
    getData: function() {
        return { ...this.data };
    },
    
    nextStep: function() {
        this.currentStep++;
        return this.currentStep;
    },
    
    isComplete: function() {
        return this.currentStep >= CONVERSATION_FLOW.length;
    },
    
    getCurrentFlow: function() {
        if (this.currentStep < CONVERSATION_FLOW.length) {
            return CONVERSATION_FLOW[this.currentStep];
        }
        return null;
    },
    
    setDiagnosisResults: function(results) {
        this.diagnosisResults = results;
    },
    
    getDiagnosisResults: function() {
        return this.diagnosisResults;
    },
    
    setProcessing: function(state) {
        this.isProcessing = state;
    },
    
    endConversation: function() {
        this.conversationEnded = true;
    },
    
    exportState: function() {
        return {
            currentStep: this.currentStep,
            data: { ...this.data },
            isProcessing: this.isProcessing,
            conversationEnded: this.conversationEnded,
            diagnosisResults: [...this.diagnosisResults],
            timestamp: new Date().toISOString()
        };
    }
};

if (typeof module !== 'undefined' && module.exports) {
    module.exports = ChatState;
}