const AgoraService = {
    client: null,
    localAudioTrack: null,
    isInitialized: false,
    isListening: false,
    isConnected: false,
    sessionId: null,
    channelName: null,
    uid: null,
    token: null,
    recognition: null,
    detectedLanguage: 'en-US',
    onTranscription: null,
    onAIResponse: null,
    onError: null,
    onStatusChange: null,
    ttsEnabled: true,
    voicesLoaded: false,
    asrTaskId: null,
    asrEnabled: false,
    
    init: async function(options = {}) {
        this.sessionId = this.generateSessionId();
        this.channelName = options.channelName || `leafguard_${this.sessionId}`;
        this.uid = options.uid || Math.floor(Math.random() * 100000);
        
        this.loadVoices();
        
        if (typeof AgoraRTC !== 'undefined') {
            try {
                this.client = AgoraRTC.createClient({ mode: 'rtc', codec: 'vp8' });
                this.setupAgoraEventHandlers();
                this.asrEnabled = true;
            } catch (e) {
                console.log('Agora RTC init failed, using Web Speech API fallback');
            }
        }
        
        if (this.checkSpeechRecognitionSupport()) {
            this.isInitialized = true;
            return true;
        }
        
        this.handleError('SPEECH_NOT_SUPPORTED', 'Speech recognition not supported in this browser. Please use Chrome, Edge, or Safari.');
        return false;
    },
    
    setupAgoraEventHandlers: function() {
        if (!this.client) return;
        
        this.client.on('user-published', async (user, mediaType) => {
            await this.client.subscribe(user, mediaType);
            if (mediaType === 'audio') {
                user.audioTrack.play();
            }
        });
        
        this.client.on('user-unpublished', (user) => {});
        
        this.client.on('connection-state-change', (curState, prevState) => {
            this.isConnected = curState === 'CONNECTED';
            if (this.onStatusChange) {
                this.onStatusChange(curState);
            }
        });
        
        this.client.on('token-privilege-will-expire', async () => {
            const newToken = await this.fetchToken();
            if (newToken) {
                await this.client.renewToken(newToken);
            }
        });
    },
    
    fetchToken: async function() {
        if (CONFIG.AGORA.TOKEN_SERVER) {
            try {
                const response = await fetch(CONFIG.AGORA.TOKEN_SERVER, {
                    method: 'POST',
                    headers: { 'Content-Type': 'application/json' },
                    body: JSON.stringify({
                        channelName: this.channelName,
                        uid: this.uid
                    })
                });
                const data = await response.json();
                return data.token;
            } catch (e) {
                return null;
            }
        }
        return null;
    },
    
    joinChannel: async function() {
        if (!this.client) return false;
        
        try {
            this.token = await this.fetchToken();
            await this.client.join(
                CONFIG.AGORA.APP_ID,
                this.channelName,
                this.token,
                this.uid
            );
            this.isConnected = true;
            return true;
        } catch (e) {
            this.handleError('JOIN_FAILED', e.message);
            return false;
        }
    },
    
    startAgoraASR: async function() {
        if (!this.client || !this.isConnected) {
            const joined = await this.joinChannel();
            if (!joined) return false;
        }
        
        try {
            this.localAudioTrack = await AgoraRTC.createMicrophoneAudioTrack({
                encoderConfig: {
                    sampleRate: 16000,
                    stereo: false
                }
            });
            
            await this.client.publish([this.localAudioTrack]);
            
            await this.startASRTask();
            
            this.isListening = true;
            if (this.onStatusChange) {
                this.onStatusChange('LISTENING');
            }
            
            return true;
        } catch (e) {
            this.handleError('ASR_START_FAILED', e.message);
            return false;
        }
    },
    
    startASRTask: async function() {
        const acquireUrl = `https://api.agora.io/v1/projects/${CONFIG.AGORA.APP_ID}/rtsc/speech-to-text/builderTokens`;
        
        const credentials = btoa(`${CONFIG.AGORA.APP_ID}:${CONFIG.AGORA.APP_CERTIFICATE}`);
        
        try {
            const acquireResponse = await fetch(acquireUrl, {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                    'Authorization': `Basic ${credentials}`
                },
                body: JSON.stringify({
                    instanceId: this.sessionId
                })
            });
            
            if (!acquireResponse.ok) {
                throw new Error('Failed to acquire ASR token');
            }
            
            const acquireData = await acquireResponse.json();
            const builderToken = acquireData.tokenName;
            
            const startUrl = `https://api.agora.io/v1/projects/${CONFIG.AGORA.APP_ID}/rtsc/speech-to-text/tasks?builderToken=${builderToken}`;
            
            const startResponse = await fetch(startUrl, {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                    'Authorization': `Basic ${credentials}`
                },
                body: JSON.stringify({
                    audio: {
                        subscribeSource: 'AGORARTC',
                        agoraRtcConfig: {
                            channelName: this.channelName,
                            uid: String(this.uid),
                            token: this.token || '',
                            channelType: 'LIVE_TYPE',
                            subscribeConfig: {
                                subscribeMode: 'CHANNEL_MODE'
                            }
                        }
                    },
                    config: {
                        features: ['RECOGNIZE'],
                        recognizeConfig: {
                            language: this.detectedLanguage || 'en-US',
                            model: 'Model',
                            output: {
                                destinations: ['WebhookDestination'],
                                agoraRTCDataStream: {
                                    channelName: this.channelName,
                                    uid: String(this.uid + 1)
                                }
                            }
                        }
                    }
                })
            });
            
            if (!startResponse.ok) {
                throw new Error('Failed to start ASR task');
            }
            
            const startData = await startResponse.json();
            this.asrTaskId = startData.taskId;
            
            this.subscribeToASRResults();
            
            return true;
        } catch (e) {
            console.log('Agora ASR unavailable, using Web Speech API');
            this.startWebSpeechRecognition();
            return false;
        }
    },
    
    subscribeToASRResults: function() {
        if (!this.client) return;
        
        this.client.on('stream-message', (uid, data) => {
            try {
                const message = JSON.parse(new TextDecoder().decode(data));
                if (message.text) {
                    if (this.onTranscription) {
                        this.onTranscription({
                            interim: message.isFinal ? '' : message.text,
                            final: message.isFinal ? message.text : '',
                            isFinal: message.isFinal
                        });
                    }
                    
                    if (message.isFinal && message.text.trim()) {
                        this.processVoiceInput(message.text.trim());
                    }
                }
            } catch (e) {}
        });
    },
    
    stopASRTask: async function() {
        if (!this.asrTaskId) return;
        
        const credentials = btoa(`${CONFIG.AGORA.APP_ID}:${CONFIG.AGORA.APP_CERTIFICATE}`);
        const stopUrl = `https://api.agora.io/v1/projects/${CONFIG.AGORA.APP_ID}/rtsc/speech-to-text/tasks/${this.asrTaskId}?builderToken=${this.asrTaskId}`;
        
        try {
            await fetch(stopUrl, {
                method: 'DELETE',
                headers: {
                    'Authorization': `Basic ${credentials}`
                }
            });
        } catch (e) {}
        
        this.asrTaskId = null;
    },
    
    stopAgoraASR: async function() {
        await this.stopASRTask();
        
        if (this.localAudioTrack) {
            this.localAudioTrack.close();
            await this.client.unpublish([this.localAudioTrack]);
            this.localAudioTrack = null;
        }
        
        this.isListening = false;
        if (this.onStatusChange) {
            this.onStatusChange('STOPPED');
        }
    },
    
    checkSpeechRecognitionSupport: function() {
        return 'webkitSpeechRecognition' in window || 'SpeechRecognition' in window;
    },
    
    loadVoices: function() {
        if ('speechSynthesis' in window) {
            const loadVoicesHandler = () => {
                this.voicesLoaded = true;
            };
            
            if (speechSynthesis.getVoices().length > 0) {
                this.voicesLoaded = true;
            } else {
                speechSynthesis.addEventListener('voiceschanged', loadVoicesHandler);
            }
        }
    },
    
    loadAgoraSDK: function() {
        return new Promise((resolve, reject) => {
            const script = document.createElement('script');
            script.src = 'https://download.agora.io/sdk/release/AgoraRTC_N-4.19.0.js';
            script.onload = resolve;
            script.onerror = () => reject(new Error('Failed to load Agora SDK'));
            document.head.appendChild(script);
        });
    },
    
    setupEventHandlers: function() {
        if (!this.client) return;
        
        this.client.on('user-published', async (user, mediaType) => {
            await this.client.subscribe(user, mediaType);
            
            if (mediaType === 'audio') {
                user.audioTrack.play();
            }
        });
        
        this.client.on('user-unpublished', (user) => {
        });
        
        this.client.on('connection-state-change', (curState, prevState) => {
            this.isConnected = curState === 'CONNECTED';
            
            if (this.onStatusChange) {
                this.onStatusChange(curState);
            }
        });
        
        this.client.on('exception', (event) => {
        });
    },
    
    connect: async function() {
        if (!this.isInitialized) {
            return false;
        }
        
        try {
            const token = await this.getToken();
            
            await this.client.join(
                CONFIG.AGORA.APP_ID,
                this.channelName,
                token,
                this.uid
            );
            
            this.isConnected = true;
            
            await this.startSTTSession();
            
            return true;
            
        } catch (error) {
            this.handleError('CONNECTION_FAILED', error.message);
            return false;
        }
    },
    
    getToken: async function() {
        if (CONFIG.AGORA.TOKEN_SERVER) {
            try {
                const response = await fetch(CONFIG.AGORA.TOKEN_SERVER, {
                    method: 'POST',
                    headers: { 'Content-Type': 'application/json' },
                    body: JSON.stringify({
                        channelName: this.channelName,
                        uid: this.uid,
                        appId: CONFIG.AGORA.APP_ID,
                        appCertificate: CONFIG.AGORA.APP_CERTIFICATE
                    })
                });
                
                const data = await response.json();
                return data.token;
                
            } catch (error) {
                return null;
            }
        }
        
        return null;
    },
    
    startListening: async function() {
        if (!this.isConnected) {
            await this.connect();
        }
        
        try {
            this.localAudioTrack = await AgoraRTC.createMicrophoneAudioTrack({
                encoderConfig: 'speech_standard'
            });
            
            await this.client.publish([this.localAudioTrack]);
            
            this.isListening = true;
            
            if (this.onStatusChange) {
                this.onStatusChange('LISTENING');
            }
            
            return true;
            
        } catch (error) {
            this.handleError('MIC_ACCESS_DENIED', 'Microphone access was denied');
            return false;
        }
    },
    
    stopListening: async function() {
        if (this.localAudioTrack) {
            this.localAudioTrack.close();
            await this.client.unpublish([this.localAudioTrack]);
            this.localAudioTrack = null;
        }
        
        this.isListening = false;
        
        if (this.onStatusChange) {
            this.onStatusChange('STOPPED');
        }
    },
    
    startSTTSession: async function() {
        const sttConfig = {
            channelName: this.channelName,
            uid: this.uid,
            languages: CONFIG.AGORA.STT_LANGUAGES,
            enablePunctuation: true,
            enableInterimResults: true
        };
        
        try {
            if ('webkitSpeechRecognition' in window || 'SpeechRecognition' in window) {
                this.startWebSpeechRecognition();
            }
            
        } catch (error) {
            this.handleError('STT_FAILED', error.message);
        }
    },
    
    startWebSpeechRecognition: function() {
        const SpeechRecognition = window.SpeechRecognition || window.webkitSpeechRecognition;
        this.recognition = new SpeechRecognition();
        
        this.recognition.continuous = true;
        this.recognition.interimResults = true;
        this.recognition.lang = LANGUAGES.currentLanguage || 'en-US';
        
        this.recognition.onresult = (event) => {
            let interimTranscript = '';
            let finalTranscript = '';
            
            for (let i = event.resultIndex; i < event.results.length; i++) {
                const transcript = event.results[i][0].transcript;
                
                if (event.results[i].isFinal) {
                    finalTranscript += transcript;
                } else {
                    interimTranscript += transcript;
                }
            }
            
            if (this.onTranscription) {
                this.onTranscription({
                    interim: interimTranscript,
                    final: finalTranscript,
                    isFinal: finalTranscript.length > 0
                });
            }
            
            if (finalTranscript) {
                this.detectedLanguage = this.recognition.lang;
                this.processVoiceInput(finalTranscript);
            }
        };
        
        this.recognition.onerror = (event) => {
            this.handleError('SPEECH_ERROR', event.error);
        };
        
        this.recognition.onend = () => {
            if (this.isListening) {
                try {
                    this.recognition.start();
                } catch (e) {
                }
            }
        };
        
        this.recognition.start();
    },
    
    setRecognitionLanguage: function(langCode) {
        if (this.recognition) {
            this.recognition.lang = langCode;
        }
        this.detectedLanguage = langCode;
    },
    
    detectLanguage: function(text) {
        const languagePatterns = {
            'hi-IN': /[\u0900-\u097F]/,
            'bn-IN': /[\u0980-\u09FF]/,
            'ta-IN': /[\u0B80-\u0BFF]/,
            'te-IN': /[\u0C00-\u0C7F]/,
            'mr-IN': /[\u0900-\u097F]/,
            'gu-IN': /[\u0A80-\u0AFF]/,
            'kn-IN': /[\u0C80-\u0CFF]/,
            'ml-IN': /[\u0D00-\u0D7F]/,
            'pa-IN': /[\u0A00-\u0A7F]/,
            'zh-CN': /[\u4E00-\u9FFF]/,
            'ja-JP': /[\u3040-\u309F\u30A0-\u30FF]/,
            'ko-KR': /[\uAC00-\uD7AF\u1100-\u11FF]/,
            'th-TH': /[\u0E00-\u0E7F]/,
            'ar-SA': /[\u0600-\u06FF]/,
            'he-IL': /[\u0590-\u05FF]/,
            'ru-RU': /[\u0400-\u04FF]/,
            'el-GR': /[\u0370-\u03FF]/,
            'vi-VN': /[àáạảãâầấậẩẫăằắặẳẵèéẹẻẽêềếệểễìíịỉĩòóọỏõôồốộổỗơờớợởỡùúụủũưừứựửữỳýỵỷỹđ]/i,
            'tl-PH': /\b(ang|ng|mga|sa|na|at|ay|ko|mo|po|oo|hindi|ako|ikaw|siya|kami|tayo|sila)\b/i,
            'id-ID': /\b(yang|dan|di|ini|itu|dengan|untuk|tidak|ada|dari|saya|anda|mereka)\b/i,
            'ms-MY': /\b(yang|dan|di|ini|itu|dengan|untuk|tidak|ada|dari|saya|anda|mereka|tetapi)\b/i,
            'es-ES': /\b(el|la|los|las|un|una|de|en|que|es|por|con|para|como|pero|más|este|esta|hola|sí|no|gracias|buenos|días)\b/i,
            'fr-FR': /\b(le|la|les|un|une|de|en|que|est|pour|avec|dans|sur|ce|cette|je|tu|il|elle|nous|vous|bonjour|oui|non|merci)\b/i,
            'de-DE': /\b(der|die|das|ein|eine|und|ist|von|mit|für|auf|den|dem|des|ich|du|er|sie|wir|ihr)\b/i,
            'it-IT': /\b(il|la|lo|gli|le|un|una|di|in|che|è|per|con|non|sono|come|questo|questa|io|tu|lui|lei|noi|voi)\b/i,
            'pt-BR': /\b(o|a|os|as|um|uma|de|em|que|é|para|com|não|por|como|mais|este|esta|eu|você|ele|ela|nós|vocês)\b/i,
            'nl-NL': /\b(de|het|een|van|en|in|is|op|te|dat|die|voor|met|zijn|als|aan|maar|om|ook|werd|bij)\b/i,
            'pl-PL': /\b(i|w|na|do|z|że|to|nie|się|jest|co|jak|po|ale|za|od|tak|czy|lub|oraz)\b/i,
            'tr-TR': /\b(bir|ve|bu|için|ile|da|de|ne|var|ben|sen|o|biz|siz|onlar|gibi|daha|çok|ama|ki)\b/i,
            'uk-UA': /[\u0400-\u04FF]/,
            'sw-KE': /\b(na|ya|wa|ni|kwa|au|lakini|hii|hiyo|yake|wao|sisi|wewe|mimi|nini|vipi|sana)\b/i
        };
        
        for (const [langCode, pattern] of Object.entries(languagePatterns)) {
            if (pattern.test(text)) {
                return langCode;
            }
        }
        
        return 'en-US';
    },
    
    processVoiceInput: function(transcript) {
        if (CONFIG.FEATURES.ENABLE_AUTO_LANGUAGE_RESPONSE) {
            const detected = this.detectLanguage(transcript);
            if (detected !== this.detectedLanguage) {
                this.detectedLanguage = detected;
                if (typeof LANGUAGES !== 'undefined' && LANGUAGES.setLanguage) {
                    LANGUAGES.setLanguage(detected);
                    if (typeof App !== 'undefined' && App.applyLanguage) {
                        App.updateLanguageButton();
                        App.applyLanguage();
                    }
                }
            }
        }
        
        if (typeof Chat !== 'undefined' && Chat.processUserInput) {
            Chat.processUserInput(transcript);
        }
    },
    
    sendToAI: async function(text, context = {}) {
        const detectedLang = this.detectLanguage(text);
        
        const aiRequest = {
            message: text,
            sessionId: this.sessionId,
            language: detectedLang,
            context: {
                ...context,
                plantType: ChatState.data.plantType,
                symptoms: ChatState.data.symptoms,
                environment: ChatState.data.environment,
                hasPhoto: ChatState.data.hasPhoto,
                userLanguage: detectedLang
            },
            systemPrompt: this.getSystemPrompt(detectedLang)
        };
        
        try {
            const response = await this.simulateAIResponse(aiRequest);
            
            if (this.onAIResponse) {
                this.onAIResponse(response);
            }
            
            return response;
            
        } catch (error) {
            this.handleError('AI_ERROR', error.message);
            return null;
        }
    },
    
    getSystemPrompt: function(language = 'en-US') {
        const langName = this.getLanguageName(language);
        
        return `You are Shyve, the AI assistant for LEAFGUARD by Team SAS - a plant disease diagnosis application.

CRITICAL INSTRUCTIONS:
1. ALWAYS respond in the SAME LANGUAGE the user writes in. If they write in ${langName}, respond in ${langName}.
2. You ONLY help with plant diseases, agriculture, and farming topics.
3. If asked about non-plant topics, politely redirect to plant health in the user's language.

YOUR EXPERTISE:
- Plant disease identification and diagnosis
- Treatment recommendations for plant diseases
- Prevention tips for common plant problems
- Growing environment advice
- Agricultural best practices

RESPONSE LANGUAGE: ${langName}

Be helpful, clear, and provide actionable treatment recommendations.
Always suggest consulting local agricultural experts for severe cases.`;
    },
    
    getLanguageName: function(langCode) {
        const languageNames = {
            'en-US': 'English',
            'en-GB': 'English',
            'en-AU': 'English',
            'en-IN': 'English',
            'es-ES': 'Spanish (Español)',
            'es-MX': 'Spanish (Español)',
            'es-AR': 'Spanish (Español)',
            'fr-FR': 'French (Français)',
            'fr-CA': 'French (Français)',
            'pt-BR': 'Portuguese (Português)',
            'pt-PT': 'Portuguese (Português)',
            'hi-IN': 'Hindi (हिन्दी)',
            'bn-IN': 'Bengali (বাংলা)',
            'ta-IN': 'Tamil (தமிழ்)',
            'te-IN': 'Telugu (తెలుగు)',
            'mr-IN': 'Marathi (मराठी)',
            'gu-IN': 'Gujarati (ગુજરાતી)',
            'kn-IN': 'Kannada (ಕನ್ನಡ)',
            'ml-IN': 'Malayalam (മലയാളം)',
            'pa-IN': 'Punjabi (ਪੰਜਾਬੀ)',
            'zh-CN': 'Chinese Simplified (中文简体)',
            'zh-TW': 'Chinese Traditional (中文繁體)',
            'ja-JP': 'Japanese (日本語)',
            'ko-KR': 'Korean (한국어)',
            'vi-VN': 'Vietnamese (Tiếng Việt)',
            'th-TH': 'Thai (ไทย)',
            'id-ID': 'Indonesian (Bahasa Indonesia)',
            'ms-MY': 'Malay (Bahasa Melayu)',
            'tl-PH': 'Tagalog (Filipino)',
            'ar-SA': 'Arabic (العربية)',
            'ur-PK': 'Urdu (اردو)',
            'sw-KE': 'Swahili (Kiswahili)',
            'ha-NG': 'Hausa',
            'yo-NG': 'Yoruba',
            'am-ET': 'Amharic (አማርኛ)',
            'de-DE': 'German (Deutsch)',
            'it-IT': 'Italian (Italiano)',
            'nl-NL': 'Dutch (Nederlands)',
            'ru-RU': 'Russian (Русский)',
            'uk-UA': 'Ukrainian (Українська)',
            'pl-PL': 'Polish (Polski)',
            'tr-TR': 'Turkish (Türkçe)',
            'el-GR': 'Greek (Ελληνικά)',
            'he-IL': 'Hebrew (עברית)',
            'fa-IR': 'Persian (فارسی)',
            'ne-NP': 'Nepali (नेपाली)',
            'si-LK': 'Sinhala (සිංහල)',
            'my-MM': 'Burmese (မြန်မာ)',
            'km-KH': 'Khmer (ខ្មែរ)'
        };
        
        return languageNames[langCode] || 'English';
    },
    
    simulateAIResponse: async function(request) {
        await new Promise(resolve => setTimeout(resolve, 500));
        
        const plantType = request.context.plantType?.toLowerCase() || 'default';
        const diseases = DISEASE_DATABASE[plantType] || DISEASE_DATABASE.default;
        
        return {
            success: true,
            message: `Based on your description, I've identified potential diseases for your ${request.context.plantType || 'plant'}.`,
            diseases: diseases,
            confidence: 'high',
            language: request.language,
            timestamp: new Date().toISOString()
        };
    },
    
    speak: function(text, language = null) {
        if (!CONFIG.AGORA.ENABLE_TTS) return;
        
        if ('speechSynthesis' in window) {
            window.speechSynthesis.cancel();
            
            const currentLang = language || this.detectedLanguage || LANGUAGES.currentLanguage || 'en-US';
            const utterance = new SpeechSynthesisUtterance(text);
            utterance.lang = currentLang;
            
            if (typeof UI !== 'undefined' && UI.getFemaleVoice) {
                const femaleVoice = UI.getFemaleVoice(currentLang);
                if (femaleVoice) {
                    utterance.voice = femaleVoice;
                }
            }
            
            utterance.rate = 0.9;
            utterance.pitch = 1.1;
            utterance.volume = 1.0;
            
            window.speechSynthesis.speak(utterance);
        }
    },
    
    disconnect: async function() {
        if (this.recognition) {
            this.recognition.stop();
            this.recognition = null;
        }
        
        await this.stopListening();
        
        if (this.client && this.isConnected) {
            await this.client.leave();
        }
        
        this.isConnected = false;
        this.isListening = false;
    },
    
    generateSessionId: function() {
        return 'session_' + Date.now() + '_' + Math.random().toString(36).substr(2, 9);
    },
    
    handleError: function(code, message) {
        const error = { code, message, timestamp: new Date().toISOString() };
        
        if (this.onError) {
            this.onError(error);
        }
    },
    
    getStatus: function() {
        return {
            isInitialized: this.isInitialized,
            isConnected: this.isConnected,
            isListening: this.isListening,
            sessionId: this.sessionId,
            channelName: this.channelName,
            detectedLanguage: this.detectedLanguage
        };
    }
};

if (typeof module !== 'undefined' && module.exports) {
    module.exports = AgoraService;
}