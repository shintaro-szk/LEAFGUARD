const ImageHandler = {
    handleUpload: function(event, onComplete) {
        const file = event.target.files[0];
        
        if (!file) {
            return;
        }
        
        if (!this.isValidImageType(file)) {
            alert('Please upload a valid image file (JPEG, PNG, GIF, WebP)');
            return;
        }
        
        if (!this.isValidFileSize(file)) {
            alert('Image file is too large. Please upload an image smaller than 10MB');
            return;
        }
        
        const reader = new FileReader();
        
        reader.onload = (e) => {
            const imageData = e.target.result;
            ChatState.setData('photoData', imageData);
            UI.showImagePreview(imageData);
            
            if (typeof onComplete === 'function') {
                onComplete(imageData);
            }
        };
        
        reader.onerror = () => {
            alert('Error reading the image file. Please try again.');
        };
        
        reader.readAsDataURL(file);
    },
    
    isValidImageType: function(file) {
        const validTypes = ['image/jpeg', 'image/png', 'image/gif', 'image/webp'];
        return validTypes.includes(file.type);
    },
    
    isValidFileSize: function(file, maxSizeMB = 10) {
        const maxSizeBytes = maxSizeMB * 1024 * 1024;
        return file.size <= maxSizeBytes;
    },
    
    removeImage: function() {
        ChatState.setData('photoData', null);
        UI.hideImagePreview();
        UI.resetImageInput();
    },
    
    processWithTensorFlow: async function(imageData) {
        return new Promise((resolve) => {
            setTimeout(() => {
                const results = {
                    processed: true,
                    confidence_boost: CONFIG.CONFIDENCE_BOOST.PHOTO_UPLOADED,
                    detected_features: [
                        'leaf_spots_detected',
                        'discoloration_present',
                        'texture_abnormal'
                    ],
                    model_version: '1.0.0',
                    processing_time: '0.8s'
                };
                
                resolve(results);
            }, 1500);
        });
    },
    
    compressImage: function(imageData, maxWidth = 800, quality = 0.8) {
        return new Promise((resolve) => {
            const img = new Image();
            
            img.onload = () => {
                const canvas = document.createElement('canvas');
                let width = img.width;
                let height = img.height;
                
                if (width > maxWidth) {
                    height = (height * maxWidth) / width;
                    width = maxWidth;
                }
                
                canvas.width = width;
                canvas.height = height;
                
                const ctx = canvas.getContext('2d');
                ctx.drawImage(img, 0, 0, width, height);
                
                const compressedData = canvas.toDataURL('image/jpeg', quality);
                resolve(compressedData);
            };
            
            img.src = imageData;
        });
    },
    
    getImageMetadata: function(file) {
        return {
            name: file.name,
            type: file.type,
            size: file.size,
            sizeFormatted: this.formatFileSize(file.size),
            lastModified: new Date(file.lastModified).toISOString()
        };
    },
    
    formatFileSize: function(bytes) {
        if (bytes === 0) return '0 Bytes';
        
        const k = 1024;
        const sizes = ['Bytes', 'KB', 'MB', 'GB'];
        const i = Math.floor(Math.log(bytes) / Math.log(k));
        
        return parseFloat((bytes / Math.pow(k, i)).toFixed(2)) + ' ' + sizes[i];
    }
};

if (typeof module !== 'undefined' && module.exports) {
    module.exports = ImageHandler;
}