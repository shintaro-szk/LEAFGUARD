const App = {
    isVoiceActive: false,
    isDarkMode: false,
    recognition: null,
    recognitionRestarting: false,
    silenceTimer: null,
    lastTranscript: '',
    
    init: function() {
        LANGUAGES.init();
        UI.init();
        this.initTheme();
        this.initLanguageUI();
        this.setupEventListeners();
        this.initVoiceRecognition();
        this.applyLanguage();
        Chat.init();
    },
    
    initTheme: function() {
        const savedTheme = localStorage.getItem('leafguard_theme');
        if (savedTheme === 'dark') {
            this.enableDarkMode();
        } else if (savedTheme === 'light') {
            this.disableDarkMode();
        } else if (window.matchMedia && window.matchMedia('(prefers-color-scheme: dark)').matches) {
            this.enableDarkMode();
        }
    },
    
    enableDarkMode: function() {
        document.documentElement.setAttribute('data-theme', 'dark');
        this.isDarkMode = true;
        localStorage.setItem('leafguard_theme', 'dark');
    },
    
    disableDarkMode: function() {
        document.documentElement.removeAttribute('data-theme');
        this.isDarkMode = false;
        localStorage.setItem('leafguard_theme', 'light');
    },
    
    toggleDarkMode: function() {
        if (this.isDarkMode) {
            this.disableDarkMode();
        } else {
            this.enableDarkMode();
        }
    },
    
    initLanguageUI: function() {
        this.renderLanguageList();
        this.updateLanguageButton();
        
        document.addEventListener('click', (e) => {
            const langMenu = document.getElementById('langMenu');
            const langBtn = document.getElementById('langBtn');
            if (!langMenu.contains(e.target) && !langBtn.contains(e.target)) {
                langMenu.classList.add('hidden');
            }
        });
    },
    
    renderLanguageList: function(filter = '') {
        const langList = document.getElementById('langList');
        const filterLower = filter.toLowerCase();
        
        const filteredLangs = LANGUAGES.supported.filter(lang => 
            lang.name.toLowerCase().includes(filterLower) || 
            lang.code.toLowerCase().includes(filterLower)
        );
        
        langList.innerHTML = filteredLangs.map(lang => `
            <button onclick="selectLanguage('${lang.code}')" 
                class="w-full flex items-center gap-3 px-3 py-2 hover:bg-green-50 dark:hover:bg-green-900/30 rounded-lg transition-colors text-left ${lang.code === LANGUAGES.currentLanguage ? 'bg-green-50 dark:bg-green-900/30 text-green-700' : ''}"
                style="color: var(--text-primary);">
                <span class="text-xl">${lang.flag}</span>
                <span class="text-sm ${lang.code === LANGUAGES.currentLanguage ? 'font-semibold' : ''}">${lang.name}</span>
                ${lang.code === LANGUAGES.currentLanguage ? '<i class="fas fa-check text-green-600 ml-auto text-xs"></i>' : ''}
            </button>
        `).join('');
    },
    
    updateLanguageButton: function() {
        const langInfo = LANGUAGES.getLanguageInfo();
        if (langInfo) {
            document.getElementById('currentLangFlag').textContent = langInfo.flag;
            document.getElementById('currentLangName').textContent = langInfo.name.split(' ')[0];
        }
    },
    
    applyLanguage: function() {
        const isRTL = LANGUAGES.isRTL();
        document.documentElement.dir = isRTL ? 'rtl' : 'ltr';
        document.documentElement.lang = LANGUAGES.currentLanguage;
        
        document.getElementById('appName').textContent = LANGUAGES.getText('appName');
        document.getElementById('poweredBy').textContent = LANGUAGES.getText('poweredBy');
        document.getElementById('onlineText').textContent = LANGUAGES.getText('online');
        document.getElementById('userInput').placeholder = LANGUAGES.getText('typeOrSpeak');
        document.getElementById('voiceStatusText').textContent = LANGUAGES.getText('listening');
        document.getElementById('langSearch').placeholder = LANGUAGES.getText('selectLanguage');
        
        this.updateProgressLabels();
        
        if (this.recognition) {
            this.recognition.lang = LANGUAGES.currentLanguage;
        }
    },
    
    updateProgressLabels: function() {
        const steps = LANGUAGES.getText('steps');
        const stepLabels = document.querySelectorAll('#progressBar .flex.justify-between span');
        stepLabels.forEach((label, index) => {
            if (steps[index]) {
                label.textContent = steps[index];
            }
        });
    },
    
    initVoiceRecognition: function() {
        if (!('webkitSpeechRecognition' in window) && !('SpeechRecognition' in window)) {
            console.log('Speech recognition not supported');
            return;
        }
        
        const SpeechRecognition = window.SpeechRecognition || window.webkitSpeechRecognition;
        this.recognition = new SpeechRecognition();
        
        this.recognition.continuous = true;
        this.recognition.interimResults = true;
        this.recognition.maxAlternatives = 1;
        this.recognition.lang = LANGUAGES.currentLanguage;
        
        this.recognition.onstart = () => {
            this.recognitionRestarting = false;
            this.showListeningState(true);
        };
        
        this.recognition.onresult = (event) => {
            let interimTranscript = '';
            let finalTranscript = '';
            
            for (let i = event.resultIndex; i < event.results.length; i++) {
                const transcript = event.results[i][0].transcript;
                
                if (event.results[i].isFinal) {
                    finalTranscript += transcript;
                } else {
                    interimTranscript += transcript;
                }
            }
            
            document.getElementById('interimTranscript').textContent = interimTranscript;
            
            if (interimTranscript) {
                this.resetSilenceTimer();
            }
            
            if (finalTranscript && finalTranscript !== this.lastTranscript) {
                this.lastTranscript = finalTranscript;
                document.getElementById('interimTranscript').textContent = '';
                Chat.processUserInput(finalTranscript.trim());
            }
        };
        
        this.recognition.onerror = (event) => {
            if (event.error === 'no-speech') {
                return;
            }
            if (event.error === 'aborted') {
                return;
            }
            console.log('Speech recognition error:', event.error);
        };
        
        this.recognition.onend = () => {
            if (this.isVoiceActive && !this.recognitionRestarting) {
                this.recognitionRestarting = true;
                setTimeout(() => {
                    if (this.isVoiceActive) {
                        try {
                            this.recognition.start();
                        } catch (e) {
                            this.recognitionRestarting = false;
                        }
                    }
                }, 100);
            } else {
                this.showListeningState(false);
            }
        };
    },
    
    resetSilenceTimer: function() {
        if (this.silenceTimer) {
            clearTimeout(this.silenceTimer);
        }
        this.silenceTimer = setTimeout(() => {
        }, 2000);
    },
    
    showListeningState: function(isListening) {
        const listeningIndicator = document.getElementById('listeningIndicator');
        const voiceBtn = document.getElementById('voiceBtn');
        const voiceBtnIndicator = document.getElementById('voiceBtnIndicator');
        const voiceStatus = document.getElementById('voiceStatus');
        
        if (isListening) {
            listeningIndicator.classList.remove('hidden');
            voiceBtnIndicator.classList.remove('hidden');
            voiceStatus.classList.remove('hidden');
            voiceBtn.classList.add('text-green-600', 'bg-green-50');
            voiceBtn.innerHTML = '<i class="fas fa-microphone-slash text-xl"></i><span id="voiceBtnIndicator" class="absolute -top-1 -right-1 w-3 h-3 bg-red-500 rounded-full animate-pulse"></span>';
        } else {
            listeningIndicator.classList.add('hidden');
            voiceBtnIndicator?.classList.add('hidden');
            voiceStatus.classList.add('hidden');
            voiceBtn.classList.remove('text-green-600', 'bg-green-50');
            voiceBtn.innerHTML = '<i class="fas fa-microphone text-xl"></i><span id="voiceBtnIndicator" class="hidden absolute -top-1 -right-1 w-3 h-3 bg-red-500 rounded-full animate-pulse"></span>';
            document.getElementById('interimTranscript').textContent = '';
        }
    },
    
    async toggleVoiceInput() {
        if (this.isVoiceActive) {
            this.stopVoiceInput();
        } else {
            await this.startVoiceInput();
        }
    },
    
    async startVoiceInput() {
        if (!this.recognition) {
            this.initVoiceRecognition();
            if (!this.recognition) {
                alert('Speech recognition is not supported in your browser. Please use Chrome, Edge, or Safari.');
                return;
            }
        }
        
        try {
            await navigator.mediaDevices.getUserMedia({ audio: true });
            
            this.isVoiceActive = true;
            this.lastTranscript = '';
            this.recognition.lang = LANGUAGES.currentLanguage;
            
            try {
                this.recognition.start();
            } catch (e) {
                if (e.name === 'InvalidStateError') {
                    this.recognition.stop();
                    setTimeout(() => {
                        this.recognition.start();
                    }, 100);
                }
            }
            
        } catch (error) {
            console.error('Microphone access error:', error);
            alert('Microphone access was denied. Please allow microphone access to use voice input.');
            this.isVoiceActive = false;
        }
    },
    
    stopVoiceInput: function() {
        this.isVoiceActive = false;
        
        if (this.silenceTimer) {
            clearTimeout(this.silenceTimer);
            this.silenceTimer = null;
        }
        
        if (this.recognition) {
            try {
                this.recognition.stop();
            } catch (e) {
            }
        }
        
        this.showListeningState(false);
    },
    
    setupEventListeners: function() {
        const userInput = document.getElementById('userInput');
        if (userInput) {
            userInput.addEventListener('keypress', (event) => {
                if (event.key === 'Enter') {
                    Chat.sendMessage();
                }
            });
        }
        
        const imageInput = document.getElementById('imageInput');
        if (imageInput) {
            imageInput.addEventListener('change', (event) => {
                ImageHandler.handleUpload(event, (imageData) => {
                    setTimeout(() => {
                        UI.hideQuickReplies();
                        UI.addUserMessage(LANGUAGES.getText('photoUploaded'), imageData);
                        ChatState.setData('hasPhoto', true);
                        UI.hideUploadButton();
                        UI.hideImagePreview();
                        Chat.proceedToAnalysis();
                    }, CONFIG.TIMING.IMAGE_SUBMIT_DELAY);
                });
            });
        }
    }
};

function sendMessage() {
    Chat.sendMessage();
}

function removeImage() {
    ImageHandler.removeImage();
}

function handleImageUpload(event) {
    ImageHandler.handleUpload(event, (imageData) => {
        setTimeout(() => {
            UI.hideQuickReplies();
            UI.addUserMessage(LANGUAGES.getText('photoUploaded'), imageData);
            ChatState.setData('hasPhoto', true);
            UI.hideUploadButton();
            UI.hideImagePreview();
            Chat.proceedToAnalysis();
        }, CONFIG.TIMING.IMAGE_SUBMIT_DELAY);
    });
}

function toggleVoiceInput() {
    App.toggleVoiceInput();
}

function toggleDarkMode() {
    App.toggleDarkMode();
}

function toggleLanguageMenu() {
    const langMenu = document.getElementById('langMenu');
    langMenu.classList.toggle('hidden');
    if (!langMenu.classList.contains('hidden')) {
        document.getElementById('langSearch').focus();
        document.getElementById('langSearch').value = '';
        App.renderLanguageList();
    }
}

function filterLanguages(query) {
    App.renderLanguageList(query);
}

function selectLanguage(langCode) {
    LANGUAGES.setLanguage(langCode);
    App.updateLanguageButton();
    App.applyLanguage();
    document.getElementById('langMenu').classList.add('hidden');
    
    if (App.recognition) {
        App.recognition.lang = langCode;
    }
    
    ChatState.reset();
    document.getElementById('chatMessages').innerHTML = '';
    Chat.init();
}

document.addEventListener('DOMContentLoaded', () => {
    App.init();
});

if (typeof module !== 'undefined' && module.exports) {
    module.exports = App;
}