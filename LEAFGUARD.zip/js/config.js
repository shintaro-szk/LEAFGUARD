const CONFIG = {
    APP_NAME: 'LEAFGUARD',
    APP_VERSION: '1.0.0',
    APP_DESCRIPTION: 'AI Plant Disease Diagnosis powered by Shyve',
    AI_NAME: 'Shyve',
    DEVELOPER: 'Team SAS',

    AGORA: {
        APP_ID: '64d7534d312f444db07778ed29308dfc',
        APP_CERTIFICATE: 'b5eddc8428de408a8fe3dc4a505a266a',
        TOKEN_SERVER: '',
        STT_API_URL: 'https://api.agora.io/v1/projects/64d7534d312f444db07778ed29308dfc/rtsc/speech-to-text',
        AI_API_URL: 'https://api.agora.io/v1/projects/64d7534d312f444db07778ed29308dfc/converse',
        CHANNEL_PREFIX: 'leafguard_',
        STT_LANGUAGES: ['en-US', 'es-ES', 'es-MX', 'fr-FR', 'fr-CA', 'pt-BR', 'pt-PT', 'hi-IN', 'bn-IN', 'ta-IN', 'te-IN', 'mr-IN', 'gu-IN', 'kn-IN', 'ml-IN', 'pa-IN', 'zh-CN', 'zh-TW', 'ja-JP', 'ko-KR', 'vi-VN', 'th-TH', 'id-ID', 'ms-MY', 'tl-PH', 'ar-SA', 'ur-PK', 'sw-KE', 'de-DE', 'it-IT', 'nl-NL', 'ru-RU', 'uk-UA', 'pl-PL', 'tr-TR'],
        ENABLE_PUNCTUATION: true,
        ENABLE_INTERIM_RESULTS: true,
        ENABLE_TTS: true,
        ENABLE_AUTO_LANGUAGE_DETECT: true,
        TTS_VOICE: 'default',
        TTS_RATE: 1.0,
        TTS_PITCH: 1.0,
        VAD_ENABLED: true,
        VAD_SILENCE_DURATION: 1500,
        SESSION_TIMEOUT: 30 * 60 * 1000,
        MAX_RECORDING_DURATION: 60 * 1000,
        AUDIO_ENCODER: 'speech_standard',
        SAMPLE_RATE: 16000,
        CHANNELS: 1
    },

    API: {
        AGORA_APP_ID: '64d7534d312f444db07778ed29308dfc',
        AGORA_CHANNEL: 'leafguard_main',
        TENSORFLOW_MODEL_URL: '',
        BASE_URL: 'https://console.agora.io/project-management/LeTI1OVB2/real-time-stt'
    },

    TIMING: {
        TYPING_DELAY: 800,
        ANALYSIS_DELAY: 1000,
        RESULTS_DELAY: 2000,
        CARD_DISPLAY_INTERVAL: 500,
        IMAGE_SUBMIT_DELAY: 500,
        VOICE_FEEDBACK_DELAY: 200
    },

    UI: {
        MAX_MESSAGE_WIDTH: '80%',
        MAX_CARD_WIDTH: '85%',
        TOTAL_STEPS: 6,
        MAX_CONFIDENCE: 98,
        SHOW_VOICE_BUTTON: true,
        VOICE_BUTTON_POSITION: 'input-area'
    },

    CONFIDENCE: {
        HIGH: 80,
        MEDIUM: 60,
        LOW: 0
    },

    CONFIDENCE_BOOST: {
        SYMPTOM_MATCH: 5,
        COLOR_MATCH: 3,
        PHOTO_UPLOADED: 8,
        VOICE_INPUT: 2,
        ENVIRONMENT_MATCH: 4
    },

    FEATURES: {
        ENABLE_PHOTO_UPLOAD: true,
        ENABLE_VOICE_INPUT: true,
        ENABLE_VOICE_OUTPUT: true,
        ENABLE_OFFLINE_MODE: true,
        ENABLE_ANALYTICS: false,
        ENABLE_DEBUG_MODE: false,
        ENABLE_AUTO_LANGUAGE_RESPONSE: true,
        ENABLE_AVATAR_ANIMATION: true,
        ENABLE_DARK_MODE: true
    },

    DEBUG: {
        ENABLED: false,
        LOG_LEVEL: 'info',
        LOG_AGORA_EVENTS: true,
        LOG_CHAT_MESSAGES: true,
        SHOW_STATE_PANEL: false
    }
};

CONFIG.isAgoraConfigured = function() {
    return Boolean(this.AGORA.APP_ID && this.AGORA.APP_ID.length > 0);
};

CONFIG.getSTTUrl = function() {
    return this.AGORA.STT_API_URL;
};

CONFIG.getAIUrl = function() {
    return this.AGORA.AI_API_URL;
};

CONFIG.log = function(level, ...args) {
    if (!this.DEBUG.ENABLED) return;
    const levels = ['verbose', 'info', 'warn', 'error'];
    const currentLevelIndex = levels.indexOf(this.DEBUG.LOG_LEVEL);
    const messageLevelIndex = levels.indexOf(level);
    if (messageLevelIndex >= currentLevelIndex) {
        const prefix = `[${this.APP_NAME} ${level.toUpperCase()}]`;
        console[level === 'verbose' ? 'log' : level](prefix, ...args);
    }
};

Object.freeze(CONFIG.API);
Object.freeze(CONFIG.TIMING);
Object.freeze(CONFIG.UI);
Object.freeze(CONFIG.CONFIDENCE);
Object.freeze(CONFIG.CONFIDENCE_BOOST);
Object.freeze(CONFIG.FEATURES);
Object.freeze(CONFIG.DEBUG);