const DISEASE_DATABASE = {
    tomato: [
        {
            name: 'Early Blight',
            confidence: 87,
            description: 'Fungal disease causing dark spots with concentric rings on leaves.',
            treatment: [
                'Remove affected leaves',
                'Apply copper-based fungicide',
                'Improve air circulation',
                'Water at base of plant'
            ]
        },
        {
            name: 'Late Blight',
            confidence: 72,
            description: 'Serious fungal disease causing water-soaked spots and white mold.',
            treatment: [
                'Remove and destroy infected plants',
                'Apply fungicide preventively',
                'Avoid overhead watering',
                'Plant resistant varieties'
            ]
        },
        {
            name: 'Septoria Leaf Spot',
            confidence: 65,
            description: 'Fungal disease with small circular spots with dark borders.',
            treatment: [
                'Remove lower affected leaves',
                'Mulch around plants',
                'Apply fungicide',
                'Rotate crops yearly'
            ]
        }
    ],
    
    potato: [
        {
            name: 'Late Blight',
            confidence: 85,
            description: 'Devastating disease causing dark lesions and rapid plant death.',
            treatment: [
                'Destroy infected plants immediately',
                'Apply preventive fungicides',
                'Plant certified seed potatoes',
                'Ensure good drainage'
            ]
        },
        {
            name: 'Early Blight',
            confidence: 70,
            description: 'Causes target-like spots on leaves starting from bottom.',
            treatment: [
                'Remove affected foliage',
                'Apply copper fungicide',
                'Maintain proper spacing',
                'Hill up soil around plants'
            ]
        },
        {
            name: 'Black Scurf',
            confidence: 58,
            description: 'Soil-borne fungus affecting tubers and stems.',
            treatment: [
                'Use certified seed',
                'Rotate crops 3-4 years',
                'Plant in warm soil',
                'Avoid compacted soil'
            ]
        }
    ],
    
    rice: [
        {
            name: 'Rice Blast',
            confidence: 89,
            description: 'Fungal disease causing diamond-shaped lesions on leaves.',
            treatment: [
                'Use resistant varieties',
                'Apply fungicides at early stages',
                'Balance nitrogen fertilizer',
                'Maintain proper water levels'
            ]
        },
        {
            name: 'Bacterial Leaf Blight',
            confidence: 75,
            description: 'Bacterial disease causing yellowing and wilting of leaves.',
            treatment: [
                'Use disease-free seeds',
                'Drain field periodically',
                'Apply copper bactericides',
                'Remove infected plant debris'
            ]
        },
        {
            name: 'Sheath Blight',
            confidence: 62,
            description: 'Fungal disease affecting leaf sheaths with irregular lesions.',
            treatment: [
                'Reduce plant density',
                'Lower nitrogen levels',
                'Apply fungicides',
                'Remove weeds'
            ]
        }
    ],
    
    corn: [
        {
            name: 'Northern Corn Leaf Blight',
            confidence: 82,
            description: 'Fungal disease with long, grayish-green lesions on leaves.',
            treatment: [
                'Plant resistant hybrids',
                'Apply foliar fungicides',
                'Rotate crops',
                'Till under crop residue'
            ]
        },
        {
            name: 'Gray Leaf Spot',
            confidence: 71,
            description: 'Fungal disease causing rectangular gray lesions.',
            treatment: [
                'Use resistant varieties',
                'Rotate with non-host crops',
                'Apply fungicides',
                'Reduce tillage to manage residue'
            ]
        },
        {
            name: 'Common Rust',
            confidence: 64,
            description: 'Fungal disease with reddish-brown pustules on leaves.',
            treatment: [
                'Plant resistant varieties',
                'Apply fungicides early',
                'Monitor fields regularly',
                'Remove volunteer corn'
            ]
        }
    ],
    
    pepper: [
        {
            name: 'Bacterial Spot',
            confidence: 78,
            description: 'Bacterial disease causing water-soaked spots on leaves and fruit.',
            treatment: [
                'Use disease-free seeds',
                'Apply copper sprays',
                'Avoid overhead irrigation',
                'Remove infected plants'
            ]
        },
        {
            name: 'Anthracnose',
            confidence: 70,
            description: 'Fungal disease causing sunken lesions on fruit.',
            treatment: [
                'Use resistant varieties',
                'Apply fungicides',
                'Harvest fruit promptly',
                'Rotate crops'
            ]
        },
        {
            name: 'Phytophthora Blight',
            confidence: 62,
            description: 'Water mold causing sudden wilting and plant death.',
            treatment: [
                'Improve drainage',
                'Use raised beds',
                'Apply fungicides preventively',
                'Avoid overwatering'
            ]
        }
    ],
    
    default: [
        {
            name: 'Fungal Leaf Spot',
            confidence: 75,
            description: 'Common fungal infection causing spots on leaves.',
            treatment: [
                'Remove affected leaves',
                'Improve air circulation',
                'Apply fungicide',
                'Avoid overhead watering'
            ]
        },
        {
            name: 'Bacterial Wilt',
            confidence: 68,
            description: 'Bacterial infection causing wilting and yellowing.',
            treatment: [
                'Remove infected plants',
                'Sterilize tools',
                'Rotate crops',
                'Use disease-free seeds'
            ]
        },
        {
            name: 'Nutrient Deficiency',
            confidence: 55,
            description: 'Lack of essential nutrients causing discoloration.',
            treatment: [
                'Test soil pH',
                'Apply balanced fertilizer',
                'Add organic matter',
                'Ensure proper drainage'
            ]
        }
    ]
};

const CONVERSATION_FLOW = [
    {
        id: 'plantType',
        question: "Welcome to LEAFGUARD! 🌿 I'm Shyve, your AI assistant for plant disease diagnosis. I'll help you identify potential diseases affecting your plants.\n\nTo get started, what type of plant are you concerned about?",
        quickReplies: ['Tomato', 'Potato', 'Rice', 'Corn', 'Pepper', 'Other'],
        field: 'plantType',
        step: 1
    },
    {
        id: 'symptoms',
        question: "Got it! Now, please describe the symptoms you're seeing on your {plantType} plant. What does the damage look like?",
        quickReplies: ['Spots on leaves', 'Holes in leaves', 'Curling leaves', 'Stunted growth', 'Rotting', 'Other'],
        field: 'symptoms',
        step: 2
    },
    {
        id: 'leafColorChanges',
        question: "Are there any color changes on the leaves? Please describe what you see.",
        quickReplies: ['Yellow spots', 'Brown patches', 'Black spots', 'White powder', 'No color change', 'Multiple colors'],
        field: 'leafColorChanges',
        step: 3
    },
    {
        id: 'discoloration',
        question: "Is there any discoloration on the stems, fruits, or roots?",
        quickReplies: ['Yes, on stems', 'Yes, on fruits', 'Yes, on roots', 'Multiple areas', 'No discoloration'],
        field: 'discoloration',
        step: 4
    },
    {
        id: 'wilting',
        question: "Is your plant showing signs of wilting, even when watered?",
        quickReplies: ['Yes, severe wilting', 'Mild wilting', 'Only in heat', 'No wilting'],
        field: 'wilting',
        step: 5
    },
    {
        id: 'environment',
        question: "Tell me about the growing environment. What are the conditions like?",
        quickReplies: ['Hot & humid', 'Hot & dry', 'Cool & wet', 'Indoor', 'Greenhouse', 'Outdoor field'],
        field: 'environment',
        step: 6
    },
    {
        id: 'photo',
        question: "Would you like to upload a photo of your plant? This can help improve the diagnosis accuracy. 📸",
        quickReplies: ['Yes, upload photo', 'No, skip this'],
        field: 'hasPhoto',
        isPhotoStep: true,
        step: 7
    }
];

const FOLLOWUP_RESPONSES = {
    moreInfo: {
        template: `📚 **More about {diseaseName}**

{description}

**Prevention Tips:**
• Use resistant plant varieties
• Practice crop rotation
• Maintain proper plant spacing
• Monitor plants regularly
• Remove infected plant debris

**When to Seek Expert Help:**
If symptoms spread rapidly or affect more than 30% of your crop, contact your local agricultural extension office immediately.`
    },
    
    prevention: {
        text: `🛡️ **General Prevention Tips**

1. **Sanitation**: Remove and destroy infected plant material

2. **Water Management**: Water at the base, avoid wet foliage

3. **Air Circulation**: Proper spacing between plants

4. **Resistant Varieties**: Choose disease-resistant cultivars

5. **Crop Rotation**: Don't plant same family crops in same spot

6. **Soil Health**: Maintain proper pH and nutrients

7. **Regular Monitoring**: Catch problems early!`
    },
    
    goodbye: {
        text: `Thank you for using LEAFGUARD! 🌿

Remember:
• Early detection saves crops
• Always follow integrated pest management
• Consult local agricultural experts for severe cases

I'm Shyve, and it was my pleasure helping you today. Goodbye and happy farming! 👋`
    },
    
    general: {
        text: `I'm Shyve, here to help! You can:

• Start a **new diagnosis** for another plant
• Ask about **prevention tips**
• Get **more details** about the diagnosed diseases
• **End** the conversation

What would you like to do?`
    }
};

if (typeof module !== 'undefined' && module.exports) {
    module.exports = {
        DISEASE_DATABASE,
        CONVERSATION_FLOW,
        FOLLOWUP_RESPONSES
    };
}