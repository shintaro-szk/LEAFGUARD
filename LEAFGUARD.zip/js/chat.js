const Chat = {
    userLanguage: 'en-US',
    
    init: function() {
        this.userLanguage = LANGUAGES.currentLanguage || 'en-US';
        UI.addBotMessage(LANGUAGES.getText('welcome'));
        UI.showQuickReplies(LANGUAGES.getText('plantTypes'), this.handleQuickReply.bind(this));
        UI.showProgressBar();
        UI.updateProgress(0);
    },
    
    handleQuickReply: function(reply) {
        UI.hideQuickReplies();
        this.processUserInput(reply);
    },
    
    sendMessage: function() {
        const text = UI.getInputValue();
        
        if (text || ChatState.data.photoData) {
            this.processUserInput(text);
            UI.clearInput();
        }
    },
    
    detectAndSetLanguage: function(text) {
        if (!CONFIG.FEATURES.ENABLE_AUTO_LANGUAGE_RESPONSE) return;
        
        const detected = AgoraService.detectLanguage(text);
        
        if (detected !== this.userLanguage) {
            this.userLanguage = detected;
            
            if (LANGUAGES.translations[detected]) {
                LANGUAGES.setLanguage(detected);
                
                if (typeof App !== 'undefined') {
                    App.updateLanguageButton();
                    App.applyLanguage();
                }
            }
        }
    },
    
    processUserInput: function(text) {
        if (ChatState.isProcessing || ChatState.conversationEnded) return;
        
        this.detectAndSetLanguage(text);
        
        const currentFlow = ChatState.getCurrentFlow();
        
        if (currentFlow && currentFlow.isPhotoStep) {
            this.handlePhotoStep(text);
            return;
        }
        
        UI.addUserMessage(text);
        
        if (currentFlow) {
            ChatState.setData(currentFlow.field, text);
            ChatState.nextStep();
            UI.updateProgress(ChatState.currentStep);
            
            if (ChatState.currentStep < CONVERSATION_FLOW.length) {
                this.showNextQuestion();
            }
        } else {
            this.handleFollowUp(text);
        }
    },
    
    handlePhotoStep: function(text) {
        const lowerText = text.toLowerCase();
        
        const yesPatterns = ['yes', 'upload', 'sí', 'si', 'oui', 'हां', 'हाँ', '是', '是的', 'oo', 'ya', 'ja', 'sim', 'نعم', 'да', 'tak', 'evet', 'ναι', 'có', 'iya', 'baik'];
        const isYes = yesPatterns.some(pattern => lowerText.includes(pattern));
        
        if (isYes) {
            UI.addUserMessage(text);
            UI.showTypingIndicator();
            
            setTimeout(() => {
                UI.removeTypingIndicator();
                UI.addBotMessage(LANGUAGES.getText('uploadPrompt'));
                UI.showUploadButton();
                UI.showQuickReplies([LANGUAGES.getText('skipPhoto')], this.handleQuickReply.bind(this));
            }, CONFIG.TIMING.TYPING_DELAY);
            
        } else if (ChatState.data.photoData) {
            UI.addUserMessage(LANGUAGES.getText('photoUploaded'), ChatState.data.photoData);
            ChatState.setData('hasPhoto', true);
            UI.hideUploadButton();
            UI.hideImagePreview();
            this.proceedToAnalysis();
            
        } else {
            UI.addUserMessage(text);
            ChatState.setData('hasPhoto', false);
            UI.hideUploadButton();
            this.proceedToAnalysis();
        }
    },
    
    showNextQuestion: function() {
        UI.showTypingIndicator();
        
        setTimeout(() => {
            UI.removeTypingIndicator();
            
            const step = ChatState.currentStep;
            let question = '';
            let replies = [];
            
            switch(step) {
                case 1:
                    question = LANGUAGES.getText('askSymptoms', { plantType: ChatState.data.plantType });
                    replies = LANGUAGES.getText('symptoms');
                    break;
                case 2:
                    question = LANGUAGES.getText('askLeafColor');
                    replies = LANGUAGES.getText('leafColors');
                    break;
                case 3:
                    question = LANGUAGES.getText('askDiscoloration');
                    replies = LANGUAGES.getText('discoloration');
                    break;
                case 4:
                    question = LANGUAGES.getText('askWilting');
                    replies = LANGUAGES.getText('wilting');
                    break;
                case 5:
                    question = LANGUAGES.getText('askEnvironment');
                    replies = LANGUAGES.getText('environment');
                    break;
                case 6:
                    question = LANGUAGES.getText('askPhoto');
                    replies = LANGUAGES.getText('photoOptions');
                    break;
                default:
                    question = CONVERSATION_FLOW[step]?.question || '';
                    replies = CONVERSATION_FLOW[step]?.quickReplies || [];
            }
            
            UI.addBotMessage(question);
            UI.showQuickReplies(replies, this.handleQuickReply.bind(this));
        }, CONFIG.TIMING.TYPING_DELAY);
    },
    
    proceedToAnalysis: function() {
        UI.hideQuickReplies();
        ChatState.setProcessing(true);
        
        UI.showTypingIndicator();
        
        setTimeout(() => {
            UI.removeTypingIndicator();
            
            const data = ChatState.getData();
            const analysisMessage = `${LANGUAGES.getText('analyzing')}

${LANGUAGES.getText('processing')}
✓ ${LANGUAGES.getText('plantTypeLabel')}: ${data.plantType}
✓ ${LANGUAGES.getText('symptomsLabel')}: ${data.symptoms}
✓ ${LANGUAGES.getText('leafChangesLabel')}: ${data.leafColorChanges}
✓ ${LANGUAGES.getText('environmentLabel')}: ${data.environment}
${data.hasPhoto ? '✓ ' + LANGUAGES.getText('photoAnalysis') : '○ ' + LANGUAGES.getText('noPhoto')}`;
            
            UI.addBotMessage(analysisMessage);
            
            UI.showTypingIndicator();
            
            setTimeout(() => {
                UI.removeTypingIndicator();
                this.displayResults();
            }, CONFIG.TIMING.RESULTS_DELAY);
            
        }, CONFIG.TIMING.ANALYSIS_DELAY);
    },
    
    displayResults: function() {
        const data = ChatState.getData();
        const plantType = data.plantType.toLowerCase();
        
        let diseases = DISEASE_DATABASE[plantType] || DISEASE_DATABASE.default;
        
        diseases = diseases.map(d => {
            let conf = d.confidence;
            
            if (data.symptoms.toLowerCase().includes('spot')) {
                conf += CONFIG.CONFIDENCE_BOOST.SYMPTOM_MATCH;
            }
            if (data.leafColorChanges.toLowerCase().includes('yellow')) {
                conf += CONFIG.CONFIDENCE_BOOST.COLOR_MATCH;
            }
            if (data.hasPhoto) {
                conf += CONFIG.CONFIDENCE_BOOST.PHOTO_UPLOADED;
            }
            
            return { ...d, confidence: Math.min(conf, CONFIG.UI.MAX_CONFIDENCE) };
        }).sort((a, b) => b.confidence - a.confidence);
        
        ChatState.setDiagnosisResults(diseases);
        
        UI.addBotMessage(LANGUAGES.getText('diagnosisResults'), true);
        
        setTimeout(() => {
            diseases.slice(0, 3).forEach((disease, index) => {
                setTimeout(() => {
                    UI.addDiseaseCard(disease, index + 1);
                }, index * CONFIG.TIMING.CARD_DISPLAY_INTERVAL);
            });
            
            setTimeout(() => {
                UI.addBotMessage(LANGUAGES.getText('whatNext'));
                UI.showQuickReplies(
                    LANGUAGES.getText('options'),
                    this.handleQuickReply.bind(this)
                );
                ChatState.setProcessing(false);
                ChatState.currentStep = CONVERSATION_FLOW.length;
            }, CONFIG.TIMING.RESULTS_DELAY);
            
        }, CONFIG.TIMING.CARD_DISPLAY_INTERVAL);
    },
    
    handleFollowUp: function(text) {
        UI.hideQuickReplies();
        const lowerText = text.toLowerCase();
        
        const newPatterns = ['new', 'start', 'again', 'nuevo', 'comenzar', 'nouveau', 'commencer', 'नया', 'शुरू', '新', '开始', 'bagong', 'simula', 'baru', 'mulai', 'mới', 'bắt đầu', 'ใหม่', 'جديد', 'новый', 'yeni', 'νέος'];
        const endPatterns = ['end', 'bye', 'close', 'exit', 'quit', 'terminar', 'adiós', 'fin', 'au revoir', 'समाप्त', 'अलविदा', '结束', '再见', 'tapusin', 'paalam', 'selesai', 'kết thúc', 'tạm biệt', 'จบ', 'انتهى', 'وداعا', 'конец', 'пока', 'bitir', 'güle güle', 'τέλος'];
        const morePatterns = ['more', '#1', 'first', 'detail', 'más', 'primero', 'plus', 'premier', 'अधिक', 'पहला', '更多', '第一', 'higit', 'una', 'lebih', 'pertama', 'thêm', 'đầu tiên', 'เพิ่มเติม', 'المزيد', 'больше', 'daha', 'περισσότερα'];
        const preventPatterns = ['prevent', 'prevention', 'avoid', 'prevención', 'evitar', 'prévention', 'éviter', 'रोकथाम', 'बचाव', '预防', '避免', 'pag-iwas', 'iwasan', 'pencegahan', 'phòng ngừa', 'ป้องกัน', 'الوقاية', 'профилактика', 'önleme', 'πρόληψη'];
        
        const isNew = newPatterns.some(p => lowerText.includes(p));
        const isEnd = endPatterns.some(p => lowerText.includes(p));
        const isMore = morePatterns.some(p => lowerText.includes(p));
        const isPrevent = preventPatterns.some(p => lowerText.includes(p));
        
        if (isNew) {
            this.startNewDiagnosis();
        } else if (isEnd) {
            this.endConversation();
        } else if (isMore) {
            this.showMoreInfo();
        } else if (isPrevent) {
            this.showPreventionTips();
        } else {
            this.showGeneralHelp();
        }
    },
    
    startNewDiagnosis: function() {
        ChatState.reset();
        
        UI.showTypingIndicator();
        
        setTimeout(() => {
            UI.removeTypingIndicator();
            UI.addBotMessage(LANGUAGES.getText('newDiagnosis') + LANGUAGES.getText('welcome'));
            UI.showQuickReplies(LANGUAGES.getText('plantTypes'), this.handleQuickReply.bind(this));
            UI.updateProgress(0);
        }, CONFIG.TIMING.TYPING_DELAY);
    },
    
    endConversation: function() {
        ChatState.endConversation();
        
        UI.showTypingIndicator();
        
        setTimeout(() => {
            UI.removeTypingIndicator();
            UI.addBotMessage(LANGUAGES.getText('goodbye'));
            UI.hideProgressBar();
        }, CONFIG.TIMING.TYPING_DELAY);
    },
    
    showMoreInfo: function() {
        UI.showTypingIndicator();
        
        setTimeout(() => {
            UI.removeTypingIndicator();
            
            const plantType = ChatState.data.plantType.toLowerCase();
            const diseases = DISEASE_DATABASE[plantType] || DISEASE_DATABASE.default;
            const topDisease = diseases[0];
            
            const message = LANGUAGES.getText('moreInfo', {
                diseaseName: topDisease.name,
                description: topDisease.description
            });
            
            UI.addBotMessage(message);
            UI.showQuickReplies(
                [LANGUAGES.getText('options')[0], LANGUAGES.getText('options')[2], LANGUAGES.getText('options')[3]],
                this.handleQuickReply.bind(this)
            );
        }, CONFIG.TIMING.TYPING_DELAY);
    },
    
    showPreventionTips: function() {
        UI.showTypingIndicator();
        
        setTimeout(() => {
            UI.removeTypingIndicator();
            UI.addBotMessage(LANGUAGES.getText('prevention'));
            UI.showQuickReplies(
                [LANGUAGES.getText('options')[0], LANGUAGES.getText('options')[3]],
                this.handleQuickReply.bind(this)
            );
        }, CONFIG.TIMING.TYPING_DELAY);
    },
    
    showGeneralHelp: function() {
        UI.showTypingIndicator();
        
        setTimeout(() => {
            UI.removeTypingIndicator();
            UI.addBotMessage(LANGUAGES.getText('generalHelp'));
            UI.showQuickReplies(
                [LANGUAGES.getText('options')[0], LANGUAGES.getText('options')[2], LANGUAGES.getText('options')[3]],
                this.handleQuickReply.bind(this)
            );
        }, CONFIG.TIMING.TYPING_DELAY);
    }
};

if (typeof module !== 'undefined' && module.exports) {
    module.exports = Chat;
}