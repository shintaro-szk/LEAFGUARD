const UI = {
    elements: {
        chatMessages: null,
        progressBar: null,
        quickReplies: null,
        quickReplyButtons: null,
        userInput: null,
        uploadBtn: null,
        imageInput: null,
        imagePreview: null,
        previewImg: null,
        avatarContainer: null,
        soundWaves: null
    },
    
    femaleVoices: {},
    voicesLoaded: false,
    currentUtterance: null,
    
    init: function() {
        this.elements.chatMessages = document.getElementById('chatMessages');
        this.elements.progressBar = document.getElementById('progressBar');
        this.elements.quickReplies = document.getElementById('quickReplies');
        this.elements.quickReplyButtons = document.getElementById('quickReplyButtons');
        this.elements.userInput = document.getElementById('userInput');
        this.elements.uploadBtn = document.getElementById('uploadBtn');
        this.elements.imageInput = document.getElementById('imageInput');
        this.elements.imagePreview = document.getElementById('imagePreview');
        this.elements.previewImg = document.getElementById('previewImg');
        this.elements.avatarContainer = document.getElementById('avatarContainer');
        this.elements.soundWaves = document.getElementById('soundWaves');
        
        this.loadVoices();
    },
    
    loadVoices: function() {
        const loadVoicesHandler = () => {
            const voices = window.speechSynthesis.getVoices();
            
            const femaleNames = [
                'female', 'woman', 'girl', 'fiona', 'samantha', 'victoria', 'karen', 'moira', 'tessa', 
                'veena', 'lekha', 'kanya', 'mei-jia', 'sin-ji', 'ting-ting', 'yuna', 'kyoko', 'o-ren', 
                'zosia', 'luciana', 'joana', 'monica', 'paulina', 'amelie', 'aurelie', 'marie', 'nora', 
                'sara', 'anna', 'petra', 'helena', 'yelda', 'milena', 'laura', 'alice', 'elsa', 'alva', 
                'karin', 'ewa', 'carmit', 'lihi', 'hoda', 'zuzana', 'iveta', 'mariska', 'melina', 
                'damayanti', 'satu', 'ellen', 'lotte', 'claire', 'nicky', 'aude', 'audrey', 'chloe', 
                'virginie', 'agnes', 'jessica', 'seoyeon', 'sora', 'naira', 'lesya', 'daria', 'svetlana', 
                'ekaterina', 'tatyana', 'natasha', 'google', 'microsoft zira', 'microsoft hazel', 
                'microsoft susan', 'microsoft heera', 'microsoft irina', 'microsoft hedda', 
                'microsoft helena', 'microsoft sabina', 'microsoft caroline', 'microsoft julie',
                'siri', 'cortana', 'alexa', 'céline', 'léa', 'amélie', 'chantal', 'mónica', 'lucía',
                'conchita', 'penélope', 'lupe', 'mia', 'giorgia', 'bianca', 'federica', 'silvia',
                'marlene', 'vicki', 'hannah', 'maja', 'liv', 'astrid', 'tatiana', 'maxim', 'carmen',
                'ines', 'cristiano', 'vitória', 'camila', 'luana', 'joana', 'raquel', 'francisca',
                'aditi', 'raveena', 'priya', 'kajal', 'nivedita', 'swara', 'pallavi', 'zhiyu', 'yue',
                'hiujin', 'xiaoxiao', 'xiaoyi', 'nanami', 'ayumi', 'haruka', 'ichika', 'mayu', 'tomoka',
                'seoyeon', 'sunhi', 'jimin', 'yuna', 'heami', 'miren', 'chiara', 'zeina', 'hala', 'rana',
                'salma', 'laila', 'fatima', 'amira', 'dalia', 'lina', 'noura', 'heba'
            ];
            
            const maleNames = [
                'male', 'david', 'mark', 'james', 'daniel', 'thomas', 'alex', 'fred', 'ralph', 
                'albert', 'bruce', 'junior', 'jorge', 'diego', 'carlos', 'rishi', 'lee', 'yuri',
                'guy', 'gregory', 'conrad', 'liam', 'oliver', 'benjamin', 'lucas', 'henry', 'alexander',
                'william', 'jacob', 'michael', 'ethan', 'matthew', 'joseph', 'christopher', 'andrew',
                'zhiwei', 'yunyang', 'takeshi', 'hiroshi', 'kenji', 'haruki', 'jun', 'seung', 'jihoon',
                'microsoft david', 'microsoft mark', 'microsoft richard', 'microsoft george', 
                'microsoft james', 'microsoft ravi', 'microsoft pavel', 'microsoft andika'
            ];
            
            voices.forEach(voice => {
                const langCode = voice.lang;
                const baseLang = langCode.split('-')[0];
                const voiceNameLower = voice.name.toLowerCase();
                
                const isFemale = femaleNames.some(name => voiceNameLower.includes(name));
                const isMale = maleNames.some(name => voiceNameLower.includes(name));
                
                const isLikelyFemale = isFemale || (!isMale && (
                    voiceNameLower.includes('enhanced') ||
                    voiceNameLower.includes('premium') ||
                    voiceNameLower.includes('natural')
                ));
                
                if (isLikelyFemale) {
                    if (!this.femaleVoices[langCode]) {
                        this.femaleVoices[langCode] = voice;
                    }
                    if (!this.femaleVoices[baseLang]) {
                        this.femaleVoices[baseLang] = voice;
                    }
                }
                
                if (!this.femaleVoices[langCode] && !isMale) {
                    this.femaleVoices[langCode] = voice;
                }
                if (!this.femaleVoices[baseLang] && !isMale) {
                    this.femaleVoices[baseLang] = voice;
                }
            });
            
            this.voicesLoaded = true;
        };
        
        if ('speechSynthesis' in window) {
            if (speechSynthesis.getVoices().length > 0) {
                loadVoicesHandler();
            }
            speechSynthesis.addEventListener('voiceschanged', loadVoicesHandler);
        }
    },
    
    getFemaleVoice: function(langCode) {
        if (!this.voicesLoaded) {
            this.loadVoices();
        }
        
        const baseLang = langCode.split('-')[0];
        
        if (this.femaleVoices[langCode]) {
            return this.femaleVoices[langCode];
        }
        
        if (this.femaleVoices[baseLang]) {
            return this.femaleVoices[baseLang];
        }
        
        const voices = window.speechSynthesis.getVoices();
        const langVoice = voices.find(v => v.lang.startsWith(baseLang));
        if (langVoice) {
            return langVoice;
        }
        
        return this.femaleVoices['en'] || this.femaleVoices['en-US'] || voices[0];
    },
    
    startAvatarSpeaking: function() {
        if (this.elements.avatarContainer) {
            this.elements.avatarContainer.classList.add('avatar-speaking');
        }
        if (this.elements.soundWaves) {
            this.elements.soundWaves.classList.add('active');
        }
    },
    
    stopAvatarSpeaking: function() {
        if (this.elements.avatarContainer) {
            this.elements.avatarContainer.classList.remove('avatar-speaking');
        }
        if (this.elements.soundWaves) {
            this.elements.soundWaves.classList.remove('active');
        }
    },
    
    speakText: function(text, callback) {
        if (!('speechSynthesis' in window)) {
            if (callback) callback();
            return;
        }
        
        window.speechSynthesis.cancel();
        
        const currentLang = LANGUAGES.currentLanguage || 'en-US';
        const utterance = new SpeechSynthesisUtterance(text);
        
        utterance.lang = currentLang;
        
        const femaleVoice = this.getFemaleVoice(currentLang);
        if (femaleVoice) {
            utterance.voice = femaleVoice;
        }
        
        const langSettings = {
            'en-US': { rate: 0.92, pitch: 1.15, volume: 1.0 },
            'en-GB': { rate: 0.92, pitch: 1.15, volume: 1.0 },
            'en-AU': { rate: 0.92, pitch: 1.15, volume: 1.0 },
            'en-IN': { rate: 0.88, pitch: 1.12, volume: 1.0 },
            'es-ES': { rate: 0.88, pitch: 1.18, volume: 1.0 },
            'es-MX': { rate: 0.88, pitch: 1.18, volume: 1.0 },
            'fr-FR': { rate: 0.85, pitch: 1.15, volume: 1.0 },
            'fr-CA': { rate: 0.85, pitch: 1.15, volume: 1.0 },
            'de-DE': { rate: 0.88, pitch: 1.10, volume: 1.0 },
            'it-IT': { rate: 0.88, pitch: 1.18, volume: 1.0 },
            'pt-BR': { rate: 0.88, pitch: 1.18, volume: 1.0 },
            'pt-PT': { rate: 0.88, pitch: 1.15, volume: 1.0 },
            'hi-IN': { rate: 0.82, pitch: 1.12, volume: 1.0 },
            'bn-IN': { rate: 0.82, pitch: 1.12, volume: 1.0 },
            'ta-IN': { rate: 0.78, pitch: 1.12, volume: 1.0 },
            'te-IN': { rate: 0.78, pitch: 1.12, volume: 1.0 },
            'mr-IN': { rate: 0.82, pitch: 1.12, volume: 1.0 },
            'gu-IN': { rate: 0.82, pitch: 1.12, volume: 1.0 },
            'kn-IN': { rate: 0.78, pitch: 1.12, volume: 1.0 },
            'ml-IN': { rate: 0.78, pitch: 1.12, volume: 1.0 },
            'pa-IN': { rate: 0.82, pitch: 1.12, volume: 1.0 },
            'zh-CN': { rate: 0.82, pitch: 1.22, volume: 1.0 },
            'zh-TW': { rate: 0.82, pitch: 1.22, volume: 1.0 },
            'ja-JP': { rate: 0.82, pitch: 1.22, volume: 1.0 },
            'ko-KR': { rate: 0.82, pitch: 1.18, volume: 1.0 },
            'vi-VN': { rate: 0.82, pitch: 1.18, volume: 1.0 },
            'th-TH': { rate: 0.78, pitch: 1.18, volume: 1.0 },
            'id-ID': { rate: 0.88, pitch: 1.12, volume: 1.0 },
            'ms-MY': { rate: 0.88, pitch: 1.12, volume: 1.0 },
            'tl-PH': { rate: 0.88, pitch: 1.12, volume: 1.0 },
            'ar-SA': { rate: 0.82, pitch: 1.05, volume: 1.0 },
            'ur-PK': { rate: 0.82, pitch: 1.05, volume: 1.0 },
            'ru-RU': { rate: 0.82, pitch: 1.12, volume: 1.0 },
            'uk-UA': { rate: 0.82, pitch: 1.12, volume: 1.0 },
            'pl-PL': { rate: 0.82, pitch: 1.12, volume: 1.0 },
            'tr-TR': { rate: 0.82, pitch: 1.12, volume: 1.0 },
            'nl-NL': { rate: 0.88, pitch: 1.12, volume: 1.0 },
            'el-GR': { rate: 0.82, pitch: 1.12, volume: 1.0 },
            'he-IL': { rate: 0.82, pitch: 1.12, volume: 1.0 },
            'sw-KE': { rate: 0.88, pitch: 1.12, volume: 1.0 }
        };
        
        const settings = langSettings[currentLang] || { rate: 0.88, pitch: 1.12, volume: 1.0 };
        utterance.rate = settings.rate;
        utterance.pitch = settings.pitch;
        utterance.volume = settings.volume;
        
        this.currentUtterance = utterance;
        
        utterance.onstart = () => {
            this.startAvatarSpeaking();
        };
        
        utterance.onend = () => {
            this.stopAvatarSpeaking();
            this.currentUtterance = null;
            if (callback) callback();
        };
        
        utterance.onerror = () => {
            this.stopAvatarSpeaking();
            this.currentUtterance = null;
            if (callback) callback();
        };
        
        window.speechSynthesis.speak(utterance);
    },
    
    stopSpeaking: function() {
        if ('speechSynthesis' in window) {
            window.speechSynthesis.cancel();
        }
        this.stopAvatarSpeaking();
    },
    
    addBotMessage: function(text, isResult = false, speakMessage = true) {
        const messageDiv = document.createElement('div');
        messageDiv.className = 'flex items-start gap-3 message-appear';
        
        const contentClass = isResult 
            ? 'bg-gradient-to-r from-green-50 to-emerald-50 dark:from-green-900/30 dark:to-emerald-900/30 border border-green-200 dark:border-green-700' 
            : '';
        
        const cleanText = text.replace(/\*\*/g, '').replace(/[🌿🔬💡📚🛡️💊📷✓○]/g, '');
        
        messageDiv.innerHTML = `
            <div class="w-8 h-8 bg-gradient-to-br from-green-500 to-emerald-600 rounded-full flex items-center justify-center flex-shrink-0">
                <i class="fas fa-shield-alt text-white text-sm"></i>
            </div>
            <div class="${contentClass} rounded-2xl rounded-tl-md px-4 py-3 max-w-[80%]" style="background: ${isResult ? '' : 'var(--bg-bot-message)'}; color: var(--text-primary);">
                <p class="whitespace-pre-line">${text}</p>
                <button onclick="UI.speakText('${cleanText.replace(/'/g, "\\'").replace(/\n/g, ' ')}')" 
                    class="mt-2 text-xs text-green-600 hover:text-green-800 flex items-center gap-1">
                    <i class="fas fa-volume-up"></i> Listen
                </button>
            </div>
        `;
        
        this.elements.chatMessages.appendChild(messageDiv);
        this.scrollToBottom();
        
        if (speakMessage && CONFIG.FEATURES.ENABLE_VOICE_OUTPUT) {
            setTimeout(() => {
                this.speakText(cleanText);
            }, 300);
        }
    },
    
    addUserMessage: function(text, imageUrl = null) {
        const messageDiv = document.createElement('div');
        messageDiv.className = 'flex items-start gap-3 justify-end message-appear';
        
        let content = `<p class="text-white">${text}</p>`;
        if (imageUrl) {
            content = `
                <img src="${imageUrl}" class="max-w-full rounded-lg mb-2">
                <p class="text-white text-sm">📷 Photo uploaded</p>
            `;
        }
        
        messageDiv.innerHTML = `
            <div class="bg-gradient-to-r from-green-500 to-emerald-600 rounded-2xl rounded-tr-md px-4 py-3 max-w-[80%]">
                ${content}
            </div>
            <div class="w-8 h-8 bg-gray-300 dark:bg-gray-600 rounded-full flex items-center justify-center flex-shrink-0">
                <i class="fas fa-user text-gray-600 dark:text-gray-300 text-sm"></i>
            </div>
        `;
        
        this.elements.chatMessages.appendChild(messageDiv);
        this.scrollToBottom();
    },
    
    showTypingIndicator: function() {
        const typingDiv = document.createElement('div');
        typingDiv.id = 'typingIndicator';
        typingDiv.className = 'flex items-start gap-3 message-appear';
        typingDiv.innerHTML = `
            <div class="w-8 h-8 bg-gradient-to-br from-green-500 to-emerald-600 rounded-full flex items-center justify-center flex-shrink-0">
                <i class="fas fa-shield-alt text-white text-sm"></i>
            </div>
            <div class="rounded-2xl rounded-tl-md px-4 py-3" style="background: var(--bg-bot-message);">
                <div class="typing-indicator flex gap-1">
                    <span class="w-2 h-2 bg-gray-400 rounded-full"></span>
                    <span class="w-2 h-2 bg-gray-400 rounded-full"></span>
                    <span class="w-2 h-2 bg-gray-400 rounded-full"></span>
                </div>
            </div>
        `;
        
        this.elements.chatMessages.appendChild(typingDiv);
        this.scrollToBottom();
    },
    
    removeTypingIndicator: function() {
        const typing = document.getElementById('typingIndicator');
        if (typing) typing.remove();
    },
    
    showQuickReplies: function(replies, handler) {
        this.elements.quickReplyButtons.innerHTML = '';
        
        replies.forEach(reply => {
            const btn = document.createElement('button');
            btn.className = 'quick-reply-btn px-4 py-2 border text-green-700 dark:text-green-400 rounded-full hover:bg-green-50 dark:hover:bg-green-900/30 transition-all text-sm';
            btn.style.cssText = 'background: var(--bg-secondary); border-color: var(--border-color);';
            btn.textContent = reply;
            btn.onclick = () => handler(reply);
            this.elements.quickReplyButtons.appendChild(btn);
        });
        
        this.elements.quickReplies.classList.remove('hidden');
    },
    
    hideQuickReplies: function() {
        this.elements.quickReplies.classList.add('hidden');
    },
    
    updateProgress: function(step) {
        for (let i = 1; i <= CONFIG.UI.TOTAL_STEPS; i++) {
            const stepEl = document.getElementById(`step${i}`);
            const progressEl = document.getElementById(`progress${i}`);
            
            if (i < step + 1) {
                stepEl.classList.add('completed');
                stepEl.innerHTML = '<i class="fas fa-check text-xs"></i>';
                if (progressEl) progressEl.style.width = '100%';
            } else if (i === step + 1) {
                stepEl.classList.add('active');
                stepEl.classList.remove('completed');
                stepEl.textContent = i;
            } else {
                stepEl.classList.remove('active', 'completed');
                stepEl.textContent = i;
                if (progressEl) progressEl.style.width = '0%';
            }
        }
    },
    
    showProgressBar: function() {
        this.elements.progressBar.classList.remove('hidden');
    },
    
    hideProgressBar: function() {
        this.elements.progressBar.classList.add('hidden');
    },
    
    addDiseaseCard: function(disease, rank) {
        const cardDiv = document.createElement('div');
        cardDiv.className = 'flex items-start gap-3 message-appear';
        
        const confidenceColor = disease.confidence >= CONFIG.CONFIDENCE.HIGH 
            ? 'bg-red-500' 
            : disease.confidence >= CONFIG.CONFIDENCE.MEDIUM 
                ? 'bg-yellow-500' 
                : 'bg-green-500';
        
        const confidenceTextColor = disease.confidence >= CONFIG.CONFIDENCE.HIGH 
            ? 'text-red-600 dark:text-red-400' 
            : disease.confidence >= CONFIG.CONFIDENCE.MEDIUM 
                ? 'text-yellow-600 dark:text-yellow-400' 
                : 'text-green-600 dark:text-green-400';
        
        const treatmentHTML = disease.treatment
            .map(t => `<li class="flex items-start gap-1"><span>•</span> ${t}</li>`)
            .join('');
        
        const confidenceLabel = typeof LANGUAGES !== 'undefined' ? LANGUAGES.getText('confidence') : 'Confidence';
        const treatmentLabel = typeof LANGUAGES !== 'undefined' ? LANGUAGES.getText('treatment') : '💊 Recommended Treatment:';
        
        cardDiv.innerHTML = `
            <div class="w-8 h-8 flex-shrink-0"></div>
            <div class="disease-card border rounded-xl p-4 max-w-[85%] shadow-sm" style="background: var(--bg-secondary); border-color: var(--border-color);">
                <div class="flex items-center gap-2 mb-2">
                    <span class="w-6 h-6 bg-green-600 text-white rounded-full flex items-center justify-center text-sm font-bold">${rank}</span>
                    <h3 class="font-semibold" style="color: var(--text-primary);">${disease.name}</h3>
                </div>
                <p class="text-sm mb-3" style="color: var(--text-secondary);">${disease.description}</p>
                <div class="mb-3">
                    <div class="flex justify-between text-sm mb-1">
                        <span style="color: var(--text-muted);">${confidenceLabel}</span>
                        <span class="font-semibold ${confidenceTextColor}">${disease.confidence}%</span>
                    </div>
                    <div class="h-2 bg-gray-200 dark:bg-gray-700 rounded-full overflow-hidden">
                        <div class="confidence-bar h-full ${confidenceColor} rounded-full" style="width: ${disease.confidence}%"></div>
                    </div>
                </div>
                <div class="bg-green-50 dark:bg-green-900/30 rounded-lg p-3">
                    <p class="text-xs font-semibold text-green-800 dark:text-green-300 mb-2">${treatmentLabel}</p>
                    <ul class="text-xs text-green-700 dark:text-green-400 space-y-1">
                        ${treatmentHTML}
                    </ul>
                </div>
            </div>
        `;
        
        this.elements.chatMessages.appendChild(cardDiv);
        this.scrollToBottom();
    },
    
    showUploadButton: function() {
        this.elements.uploadBtn.classList.remove('hidden');
    },
    
    hideUploadButton: function() {
        this.elements.uploadBtn.classList.add('hidden');
    },
    
    showImagePreview: function(imageData) {
        this.elements.previewImg.src = imageData;
        this.elements.imagePreview.classList.remove('hidden');
    },
    
    hideImagePreview: function() {
        this.elements.imagePreview.classList.add('hidden');
    },
    
    clearInput: function() {
        this.elements.userInput.value = '';
    },
    
    getInputValue: function() {
        return this.elements.userInput.value.trim();
    },
    
    scrollToBottom: function() {
        this.elements.chatMessages.scrollTop = this.elements.chatMessages.scrollHeight;
    },
    
    resetImageInput: function() {
        this.elements.imageInput.value = '';
    }
};

if (typeof module !== 'undefined' && module.exports) {
    module.exports = UI;
}